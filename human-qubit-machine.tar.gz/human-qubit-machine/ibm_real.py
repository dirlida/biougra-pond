import requests

API_TOKEN = "pqtQBaaUiqaewLqpfDkbkUs_IegsMljDLO1SXH4H1Ut"

print("[1] Logging into NEW IBM club...")
try:
    r = requests.post(
        "https://api.quantum.ibm.com/api/Auth/Login",
        json={"apiToken": API_TOKEN},
        timeout=15
    )
    print("Status:", r.status_code)
    print(r.text[:500])
    data = r.json()
    token = data.get('id') or data.get('token')
    print(f"GOT TOKEN: {str(token)[:20]}...")

    # Try to list backends
    headers = {"X-Access-Token": token}
    r2 = requests.get("https://api.quantum.ibm.com/api/Backends", headers=headers, timeout=15)
    print("\n[2] Backends:", r2.status_code)
    print(r2.text[:1000])

except Exception as e:
    print("Error:", e)
    print("\nTrying google DNS check...")
    import socket
    print(socket.getaddrinfo("api.quantum.ibm.com", 443))
